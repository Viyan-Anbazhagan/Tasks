import { Routes } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { AddBookComponent } from './add-book/add-book.component';
import { ManageBookComponent } from './manage-book/manage-book.component';



export const routes: Routes = [
    {'path':'home','title':'Home',component:HomeComponent},
    {'path':'addbook','title':'Add Book',component:AddBookComponent},
    {'path':'managebook','title':'Manage Book',component:ManageBookComponent},
    {'path':'',redirectTo:"home" ,pathMatch:"full"}
];
