import { Component } from '@angular/core';
import { FormsModule, NgForm } from '@angular/forms';
import {  Book } from '../app.component';
import { BookdataService } from '../bookdata.service';

@Component({
  selector: 'app-add-book',
  standalone: true,
  imports: [FormsModule],
  templateUrl: './add-book.component.html',
  styleUrl: './add-book.component.css'
})
export class AddBookComponent {
constructor(public bookDataService:BookdataService){}
book: Book = {Id:0,Name:'',Author:'',Edition:0,Publisher:''};
addbook(form:NgForm):void{
    this.bookDataService.addBook(this.book);
    alert("Book added");
    this.book={Id:0,Name:'',Author:'',Edition:0,Publisher:''}
}
}
