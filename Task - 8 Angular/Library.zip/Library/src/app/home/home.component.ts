import { Component } from '@angular/core';
import { AppComponent, Book } from '../app.component';
import { CommonModule, NgForOf } from '@angular/common';
import { BookdataService } from '../bookdata.service';
import { RouterLink } from '@angular/router';
import { FormsModule } from '@angular/forms';


@Component({
  selector: 'app-home',
  standalone: true,
  imports: [AppComponent,CommonModule,NgForOf,RouterLink,FormsModule],
  templateUrl: './home.component.html',
  styleUrl: './home.component.css'
})
export class HomeComponent {
  constructor(public bookdataService:BookdataService){}
  show:boolean = true;
  book: Book = {Id:0,Name:'',Author:'',Edition:0,Publisher:''};
  viewbook(Id:number):void{
    this.book = this.bookdataService.getBookById(Id);
    this.show=!this.show;
  }
  back(){
    this.show=!this.show;
    this.book= {Id:0,Name:'',Author:'',Edition:0,Publisher:''};
  }
}

