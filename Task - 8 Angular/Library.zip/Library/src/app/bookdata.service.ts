import { Injectable } from '@angular/core';
import { Book } from './app.component';

@Injectable({
  providedIn: 'root'
})
export class BookdataService {
  private books: Book[] = [{Id:1,Name:"Core Java",Author:"Rathakrishnan.K",Edition:4,Publisher:"Raj Publishers"},
                          {Id:2,Name:"Angular",Author:"Jayakumar.S",Edition:2,Publisher:"Walter Publishers"},
                          {Id:3,Name:"DotNet",Author:"Lalitha.M",Edition:7,Publisher:"Kumar Publishers"},
                          {Id:4,Name:"TypeScript",Author:"Ramachandran.R",Edition:5,Publisher:"Raj Publishers"}];

  getBooks(): Book[] {
    return this.books;
  }

  addBook(book: Book): void {
    this.books.push(book);
  }
  getBookById(Id: number): any {
    return this.books.find(book => book.Id === Id);
  }
  deleteBookById(Id: number): void {
    const index = this.books.findIndex(book => book.Id === Id);
    if (index !== -1) {
      this.books.splice(index, 1);
    }
  }
}
