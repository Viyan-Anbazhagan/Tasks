import { Component } from '@angular/core';
import { AppComponent,Book } from '../app.component';
import { CommonModule } from '@angular/common';
import { BookdataService } from '../bookdata.service';
import { FormsModule, NgForm } from '@angular/forms';

@Component({
  selector: 'app-manage-book',
  standalone: true,
  imports: [AppComponent,CommonModule,FormsModule],
  templateUrl: './manage-book.component.html',
  styleUrl: './manage-book.component.css'
})
export class ManageBookComponent {
  constructor(public bookdataService:BookdataService){}
  show:boolean = true;
  book: Book = {Id:0,Name:'',Author:'',Edition:0,Publisher:''};
  editbook(Id:number):void{
    this.book = this.bookdataService.getBookById(Id);
    this.bookdataService.deleteBookById(Id);
    this.show=!this.show;
  }
  update(form:NgForm){
    this.bookdataService.addBook(this.book);
    this.show=!this.show;
    alert("Book updated")
    this.book= {Id:0,Name:'',Author:'',Edition:0,Publisher:''};
  }
}
